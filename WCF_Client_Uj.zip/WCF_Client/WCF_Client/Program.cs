﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WCF_Client.ServiceReference1;

namespace WCF_Client
{
    internal class Program
    {
        public static ServiceReference1.Service1Client kliens;

        public static Kutya EgyKutyaPost()
        {
            Kutya Kutya = new Kutya();
            WebClient client = new WebClient();
            JObject jObject = new JObject();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = System.Text.Encoding.UTF8;
            string result = client.UploadString("http://localhost:3000/" + "EgyKutyaHozzaAdas", jObject.ToString());
            Console.WriteLine(result);
            Kutya= JsonConvert.DeserializeObject<Kutya>(result);
            return Kutya;
        }
        static void Main(string[] args)
        {
            kliens = new ServiceReference1.Service1Client();
            Kutya ek = kliens.EgyKutyaGetCS();
            Console.WriteLine(ek.Gazdi);
            Kutya egyKutya = EgyKutyaPost();
            Console.WriteLine(egyKutya.Gazdi);
            Console.ReadKey();
            kliens.Close();
        }
    }
}
